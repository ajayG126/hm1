package com.register.user.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reservation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int reservationId;
	
	private boolean checkInDone;
	private int roomId;
	private int customerId;
	private Date fromDate;
	private Date toDate;
	public Reservation() {
		
	}
	
	public Reservation(boolean checkInDone, int roomId, int customerId, Date fromDate, Date toDate) {
		super();
		
		this.checkInDone = checkInDone;
		this.roomId = roomId;
		this.customerId = customerId;
		this.fromDate = fromDate;
		this.toDate = toDate;
	}

	
	public int getReservationId() {
		return reservationId;
	}
	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}
	public boolean isCheckInDone() {
		return checkInDone;
	}
	public void setCheckInDone(boolean checkInDone) {
		this.checkInDone = checkInDone;
	}
	public int getRoomId() {
		return roomId;
	}
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	
	
}
