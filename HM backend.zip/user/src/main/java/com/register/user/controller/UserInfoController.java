package com.register.user.controller;



import com.register.user.exception.ValidationException;
import com.register.user.model.JwtResponse;
import com.register.user.model.UserInfo;
import com.register.user.repository.UserInfoRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import java.security.NoSuchAlgorithmException;
import java.util.Map;



@RestController
public class UserInfoController {


    final
    private UserInfoRepository userInfoRepository;

//    private HashData hashData = new HashData();

    public UserInfoController(UserInfoRepository userInfoRepository) {
        this.userInfoRepository = userInfoRepository;
    }


    @PostMapping("/user")
    public Boolean create(@RequestBody Map<String, String> body) throws NoSuchAlgorithmException {
        String email = body.get("email");
        if (userInfoRepository.existsByEmail(email)){

            throw new ValidationException("Username already existed");

        }

        String password = body.get("password");
        String encodedPassword = new BCryptPasswordEncoder().encode(password);
//        String hashedPassword = hashData.get_SHA_512_SecurePassword(password);
        String firstName = body.get("firstName");
        String lastName=body.get("lastName");
        String phoneNo=body.get("phoneNo");
        String address=body.get("address");
        userInfoRepository.save(new UserInfo(email, encodedPassword, firstName,lastName,address,phoneNo));
        return true;
    }

}
