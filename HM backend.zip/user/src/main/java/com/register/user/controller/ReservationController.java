package com.register.user.controller;

import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.register.user.exception.ValidationException;
import com.register.user.model.Reservation;
import com.register.user.model.UserInfo;
import com.register.user.repository.ReservationRepo;
import com.register.user.repository.UserInfoRepository;

@RestController
public class ReservationController {
    private UserInfoRepository userInfoRepository;
private ReservationRepo reservationRepository;
    public ReservationController(UserInfoRepository userInfoRepository,ReservationRepo reservationRepository) {
        this.userInfoRepository = userInfoRepository;
        this.reservationRepository= reservationRepository;
    }
	@GetMapping("/curuser")
	public int showUser() {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
String username = userDetails.getUsername();
UserInfo user=userInfoRepository.findByEmail(username);
return user.getId();

	}
	
	@PostMapping("/reserve")
    public Boolean create(@RequestBody Map<String, String> body) throws NoSuchAlgorithmException {
		UserDetails userDetails = (UserDetails) SecurityContextHolder.getContext().getAuthentication()
                .getPrincipal();
String username = userDetails.getUsername();
UserInfo user=userInfoRepository.findByEmail(username);
		int customerId =user.getId();

		String fDate = body.get("fromDate");
		Date fromDate = Date.valueOf(fDate);
		String tDate = body.get("toDate");
		Date toDate=Date.valueOf(tDate);
		String roomIds=body.get("roomId");
		int roomId=Integer.parseInt(roomIds);
		boolean checkInDone=false;
//        String hashedPassword = hashData.get_SHA_512_SecurePassword(password);
        reservationRepository.save(new Reservation(checkInDone, roomId, customerId,fromDate,toDate));
        return true;
    }
	
	
}
