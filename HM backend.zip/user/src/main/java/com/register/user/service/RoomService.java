package com.register.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.register.user.model.Room;
import com.register.user.repository.RoomRepo;


@Service
public class RoomService {

    public RoomRepo roomRepository;
    public RoomService(final RoomRepo roomRepository){this.roomRepository = roomRepository;}

    @Transactional
    public Optional<Room> getRoom(final String roomNum)
    {
    	return this.roomRepository.findByRoomNum(roomNum);
    	
    }
    public List<Room> getAll(){
    	 List<Room> rooms = new ArrayList<Room>();
         roomRepository.findAll().forEach(room -> rooms.add(room));
         return rooms;
    }
    

}
