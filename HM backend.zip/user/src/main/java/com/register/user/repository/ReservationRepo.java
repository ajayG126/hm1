package com.register.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.register.user.model.Reservation;

public interface ReservationRepo extends JpaRepository<Reservation,Integer> {

}
