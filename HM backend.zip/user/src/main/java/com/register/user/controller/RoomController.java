package com.register.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.register.user.model.Room;
import com.register.user.repository.RoomRepo;


@RestController
public class RoomController {

    public RoomRepo roomRepository;

    public RoomController(RoomRepo roomRepository) {
        this.roomRepository = roomRepository;
    }
	 @GetMapping("/room/{roomNum}")
	    public Room show(@PathVariable String roomNum){
	  
	        return roomRepository.findByRoomNum(roomNum).orElse(new Room());
	    }

		@GetMapping("/room/All")
		public List<Room> getAll() {
            return roomRepository.findAll();
		}
}
